YSMF STORE ORGANIZER — SAFE V1
===============================

I inspected the uploaded ysmf-store(2).rar and recovered the current Git HEAD:
c0cbcbe — Add campaign film + signature autoplay fix

WHY THIS PACK USES AN ORGANIZER INSTEAD OF REPLACING YOUR WHOLE FOLDER
----------------------------------------------------------------------
Your uploaded store contains a real .git directory used by GitHub Desktop.
That hidden folder should NOT be replaced or recreated by ChatGPT.

This pack therefore organizes YOUR EXISTING PC FOLDER in place:
- preserves .git exactly
- preserves all live website paths
- preserves BACKUPS
- creates a fresh backup before moving anything
- moves old update notes and ZIP packages into _PROJECT_LOCAL
- prepares clean Drop 01 release-state folders
- adds sensible Git ignore rules for local-only files

HOW TO USE
----------
1. Extract this ZIP.
2. Copy ALL contents of the extracted folder into the ROOT of ysmf-store,
   beside index.html.
   This includes:
   - ORGANIZE_YSMF_STORE_SAFE_V1.bat
   - ORGANIZE_YSMF_STORE_SAFE_V1.ps1
   - _ORGANIZER_PAYLOAD
3. Double-click ORGANIZE_YSMF_STORE_SAFE_V1.bat.
4. Let it finish.
5. Open the store folder and confirm _PROJECT_LOCAL exists.
6. Open GitHub Desktop.
   It is normal to see:
   - old README/update docs deleted from the repository root
   - old generated ZIPs deleted from the repository root
   - .gitignore added
   Live HTML/assets should NOT show as moved simply because of this organizer.

FINAL ROOT SHOULD BE MUCH CLEANER
---------------------------------
Live:
  index.html
  shop.html
  signature.html
  minimal.html
  about.html
  product.html
  404.html
  README.md
  assets/
  .git/
  .gitignore
  BACKUPS/
  _PROJECT_LOCAL/
  BACKUP_YSMF_SITE_V2.bat
  BACKUP_YSMF_SITE_V2.ps1

Local organization:
  _PROJECT_LOCAL/CHANGE_NOTES
  _PROJECT_LOCAL/PACKAGES
  _PROJECT_LOCAL/PLANS
  _PROJECT_LOCAL/PROJECT_LOGS
  _PROJECT_LOCAL/RELEASE_FILES/DROP_01
  _PROJECT_LOCAL/LEGACY_TOOLS
  _PROJECT_LOCAL/UNSORTED_REVIEW

NOT TOUCHED
-----------
- Live HTML page paths
- assets paths / filenames
- Fourthwall config
- .git
- existing BACKUPS
