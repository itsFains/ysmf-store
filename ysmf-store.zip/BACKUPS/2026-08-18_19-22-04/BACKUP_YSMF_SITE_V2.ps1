$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$index = Join-Path $root "index.html"

if (-not (Test-Path -LiteralPath $index)) {
    Write-Host ""
    Write-Host "ERROR: index.html was not found beside the backup script." -ForegroundColor Red
    Write-Host "Put both V2 backup files directly in the YSMF store root."
    exit 1
}

$stamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$backupRoot = Join-Path $root "BACKUPS"
$dest = Join-Path $backupRoot $stamp

New-Item -ItemType Directory -Path $dest -Force | Out-Null

Write-Host ""
Write-Host "YSMF WEBSITE BACKUP V2"
Write-Host "Source:      $root"
Write-Host "Destination: $dest"
Write-Host ""

# Copy every item in the live store root except the backup archive and Git history.
$items = Get-ChildItem -LiteralPath $root -Force | Where-Object {
    $_.Name -ne "BACKUPS" -and
    $_.Name -ne ".git"
}

foreach ($item in $items) {
    $target = Join-Path $dest $item.Name
    Copy-Item -LiteralPath $item.FullName -Destination $target -Recurse -Force
}

# Verification
$sourceFiles = Get-ChildItem -LiteralPath $root -File -Recurse -Force | Where-Object {
    $_.FullName -notlike "$backupRoot*" -and
    $_.FullName -notlike "$(Join-Path $root '.git')*"
}
$backupFiles = Get-ChildItem -LiteralPath $dest -File -Recurse -Force

$manifest = @()
$manifest += "YSMF WEBSITE BACKUP"
$manifest += "Created: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
$manifest += "Source: $root"
$manifest += "Destination: $dest"
$manifest += "Source file count (excluding BACKUPS/.git): $($sourceFiles.Count)"
$manifest += "Backup file count: $($backupFiles.Count)"
$manifest += ""
$manifest += "Files:"
$manifest += ($backupFiles | ForEach-Object {
    $_.FullName.Substring($dest.Length + 1)
})

$manifestPath = Join-Path $dest "_BACKUP_MANIFEST.txt"
$manifest | Set-Content -LiteralPath $manifestPath -Encoding UTF8

# Recount after manifest is written
$finalCount = (Get-ChildItem -LiteralPath $dest -File -Recurse -Force).Count

Write-Host "Copied $($backupFiles.Count) website files."
Write-Host "Manifest created: _BACKUP_MANIFEST.txt"
Write-Host ""

if ($backupFiles.Count -lt 1) {
    Write-Host "ERROR: No website files were copied." -ForegroundColor Red
    exit 2
}

Write-Host "BACKUP COMPLETE" -ForegroundColor Green
Write-Host "Open:"
Write-Host $dest
Write-Host ""
exit 0
