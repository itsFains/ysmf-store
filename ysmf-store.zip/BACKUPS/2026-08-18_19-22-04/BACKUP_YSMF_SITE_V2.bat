@echo off
setlocal
pushd "%~dp0"

REM ============================================================
REM YSMF WEBSITE BACKUP V2
REM Put this file directly beside index.html in your YSMF store root.
REM ============================================================

if not exist "index.html" (
    echo.
    echo ============================================================
    echo   YSMF BACKUP STOPPED
    echo ============================================================
    echo.
    echo I cannot find index.html beside this backup file.
    echo.
    echo Move BACKUP_YSMF_SITE_V2.bat and
    echo BACKUP_YSMF_SITE_V2.ps1 into the ROOT of your YSMF store,
    echo the same folder that contains:
    echo.
    echo   index.html
    echo   shop.html
    echo   signature.html
    echo   minimal.html
    echo   assets\
    echo.
    pause
    popd
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0BACKUP_YSMF_SITE_V2.ps1"

set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
    echo ============================================================
    echo   BACKUP FINISHED SUCCESSFULLY
    echo ============================================================
) else (
    echo ============================================================
    echo   BACKUP FAILED - ERROR CODE %RC%
    echo ============================================================
    echo Check the message above.
)

echo.
pause
popd
endlocal
