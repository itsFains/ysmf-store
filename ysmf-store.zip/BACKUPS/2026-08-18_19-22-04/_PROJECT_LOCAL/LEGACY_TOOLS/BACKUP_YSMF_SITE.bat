@echo off
setlocal

REM ============================================================
REM YSMF WEBSITE FULL BACKUP
REM Put this .bat file in the ROOT of your YSMF store folder.
REM Double-click it BEFORE making website changes.
REM It copies the whole current site except BACKUPS and .git.
REM ============================================================

for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd_HH-mm-ss"') do set "STAMP=%%i"

set "ROOT=%~dp0"
set "DEST=%ROOT%BACKUPS\%STAMP%"

echo.
echo ============================================================
echo   YSMF WEBSITE BACKUP
echo ============================================================
echo Source:
echo %ROOT%
echo.
echo Destination:
echo %DEST%
echo.

if not exist "%ROOT%BACKUPS" mkdir "%ROOT%BACKUPS"
mkdir "%DEST%"

robocopy "%ROOT%" "%DEST%" /E /COPY:DAT /DCOPY:DAT /R:1 /W:1 /XD "%ROOT%BACKUPS" "%ROOT%.git" /NFL /NDL /NP

set "RC=%ERRORLEVEL%"

REM Robocopy exit codes 0-7 are success / non-fatal.
if %RC% LEQ 7 (
    echo.
    echo ============================================================
    echo   BACKUP COMPLETE
    echo ============================================================
    echo Saved to:
    echo %DEST%
    echo.
) else (
    echo.
    echo ============================================================
    echo   BACKUP MAY HAVE FAILED - ROBOCOPY CODE %RC%
    echo ============================================================
    echo Check the folder manually before changing the website.
    echo.
)

pause
endlocal
