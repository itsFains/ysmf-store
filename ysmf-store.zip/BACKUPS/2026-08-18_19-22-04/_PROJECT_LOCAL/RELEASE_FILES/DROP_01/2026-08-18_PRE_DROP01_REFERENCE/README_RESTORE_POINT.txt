PRE-DROP 01 REFERENCE RESTORE POINT — 18 AUG 2026

This folder contains the latest frontend files ChatGPT has built for the
normal site state.

For the safest exact backup of your real PC folder, use BACKUP_YSMF_SITE.bat.
That timestamped backup will also include your current app.js, config.js,
product.html, 404.html, images and any other local files.
