YSMF WEBSITE BACKUP SYSTEM — 18 AUGUST 2026
================================================

HOW TO INSTALL
1. Extract the CONTENTS of this ZIP into the ROOT of your YSMF store folder.
   The same folder that contains index.html, shop.html, signature.html, etc.
2. You should then see:
      BACKUP_YSMF_SITE.bat
      BACKUPS/
3. BEFORE ANY WEBSITE EDIT:
   double-click BACKUP_YSMF_SITE.bat
4. It automatically creates a timestamped full-site snapshot such as:
      BACKUPS/2026-08-18_19-05-42/
5. Then make your changes and push them with GitHub Desktop.

WHAT THE AUTOMATIC BACKUP COPIES
- All HTML pages
- assets/
- images
- CSS
- JavaScript
- config.js
- app.js
- product files
- any other site files currently in the folder

WHAT IT DOES NOT COPY
- .git   (GitHub already keeps its own history)
- BACKUPS   (prevents endless backup-inside-backup recursion)

IMPORTANT
The automatic script is the main backup system because it copies the EXACT
files currently on your PC. That means it also catches changes that ChatGPT
does not have access to.

INCLUDED REFERENCE RESTORE POINTS
BACKUPS/2026-08-18_PRE_DROP01_REFERENCE/
- Latest frontend versions we built together before Drop 01:
  index.html
  shop.html
  about.html
  signature.html (autoplay/no controls)
  minimal.html (campaign video)
  assets/styles.css

BACKUPS/2026-09-17_LAUNCH_EVE/
- Prepared launch-eve index.html
- matching styles.css

BACKUPS/2026-09-18_LAUNCH_DAY/
- Prepared launch-day index.html
- matching styles.css

IMPORTANT ABOUT config.js / app.js
I have deliberately NOT put an old config.js or app.js into the manual
reference restore point because your real store folder may contain a newer
version. The FIRST time you run BACKUP_YSMF_SITE.bat, your exact current
config.js and app.js will be preserved in the timestamped snapshot.

RECOMMENDED ROUTINE
- Before a normal edit: run backup script.
- Before 17 Sep launch-eve swap: run backup script.
- Before 18 Sep launch-day swap: run backup script.
- Before changing config.js: run backup script.
- Before any large redesign: run backup script.

RESTORING
Do not delete your current site immediately.
1. Open the BACKUPS folder.
2. Pick the snapshot from before the problem.
3. Copy the required old files back into the main YSMF store folder.
4. Commit/push the restoration with GitHub Desktop.
5. Hard refresh the live site.

You now have TWO safety nets:
- Local timestamped BACKUPS
- GitHub commit history
