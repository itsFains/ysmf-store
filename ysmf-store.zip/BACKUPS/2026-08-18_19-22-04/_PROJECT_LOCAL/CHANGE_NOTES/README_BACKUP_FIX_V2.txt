YSMF BACKUP FIX V2
===================

The first backup script had a weakness around the source/exclusion path.
This replacement uses PowerShell to copy the actual files directly and also
checks that it is installed in the correct folder.

INSTALL
1. Open your main YSMF store folder.
2. It should be the folder containing:
   index.html
   shop.html
   signature.html
   minimal.html
   assets3. Copy BOTH of these files directly into that folder:
   BACKUP_YSMF_SITE_V2.bat
   BACKUP_YSMF_SITE_V2.ps1

USE
Double-click:
BACKUP_YSMF_SITE_V2.bat

It will create:
BACKUPS\YYYY-MM-DD_HH-mm-ss\

The new backup should contain all current website files and folders except:
- BACKUPS
- .git

It also creates:
_BACKUP_MANIFEST.txt

That manifest tells you how many files were copied and lists them.

IMPORTANT
Do not put the V2 files inside the BACKUPS folder or inside a separate
"YSMF_Backup_Fix_v2" folder. Put them directly beside your live index.html.
