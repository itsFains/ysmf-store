# YSMF Store — Stage 2 update

## IMPORTANT: do NOT overwrite `assets/config.js`
Your live repository already contains your Fourthwall Storefront token and collection slugs.
This update ZIP intentionally does **not** contain `config.js`.

## Replace / upload these files
- `index.html`
- `shop.html`
- `signature.html`
- `minimal.html`
- `about.html`
- `product.html` (NEW)
- `assets/styles.css`
- `assets/app.js`

Leave your existing image assets and `assets/config.js` exactly where they are.

## What changed
1. Homepage products automatically sort apparel first and only show 8 featured items.
2. Product cards now have cleaner spacing, category labels, second-image hover where available, and link to your own product page.
3. Signature page is now a complete campaign + story + product collection page.
4. Minimal page is hidden from navigation via your existing config and has a private preview mode.
5. Custom product pages fetch Fourthwall product data by slug, show images/options/quantity and add to a custom bag.
6. Custom cart drawer uses Fourthwall's Storefront Cart API and redirects to Fourthwall hosted checkout.

## Preview YSMF Minimal before launch
Keep these in your existing `assets/config.js`:

```js
showMinimalInNavigation: false,
showMinimalTeaserOnHome: false,
minimalIsLive: false,
```

Your private working preview URL is:

`minimal.html?preview=1`

Normal visitors opening `minimal.html` only see the coming-soon screen.

When Drop 01 launches, switch:

```js
showMinimalInNavigation: true,
showMinimalTeaserOnHome: true, // optional; use true before/at launch if you want it on Home
minimalIsLive: true,
```

## Fourthwall collection slug
Your Signature page already works, so keep that slug.
Before Minimal launches, make sure `minimalCollectionSlug` matches the last part of its Fourthwall collection URL.

## Sirv recommendation
Use Sirv for your custom campaign images / lookbook photos / large homepage banners if you want automatic resizing and CDN delivery.
Do NOT re-upload Fourthwall product images to Sirv — the Storefront API already returns Fourthwall-hosted transformed image URLs.
Small files such as the IF logo can stay in `/assets` on GitHub.
