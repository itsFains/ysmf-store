YSMF STORE ORGANIZER - SAFE V2
==============================

WHY V1 FAILED
The V1 PowerShell file contained a Unicode em dash in a quoted line.
Windows PowerShell 5.1 can misread UTF-8 files without a BOM as the local
Windows code page. That converted the em dash into characters that confused
PowerShell's quote parser, producing:

"The string is missing the terminator: "."

V2 fixes that by using ASCII-only script text.

HOW TO USE
1. Delete or ignore:
   ORGANIZE_YSMF_STORE_SAFE_V1.bat
   ORGANIZE_YSMF_STORE_SAFE_V1.ps1

2. Copy these into the ROOT of the YSMF store, beside index.html:
   ORGANIZE_YSMF_STORE_SAFE_V2.bat
   ORGANIZE_YSMF_STORE_SAFE_V2.ps1
   _ORGANIZER_PAYLOAD

3. Double-click:
   ORGANIZE_YSMF_STORE_SAFE_V2.bat

4. It will:
   - verify index.html and assets exist
   - create a backup first
   - leave .git untouched
   - leave live HTML/assets paths untouched
   - leave BACKUPS untouched
   - organize old notes, packages, plans and launch files into _PROJECT_LOCAL
   - add local-only folders/tools to .gitignore

The V1 error happened before the organizer actually ran, so it should not have
moved any site files.
