@echo off
setlocal
pushd "%~dp0"

echo.
echo ============================================================
echo   YSMF STORE ORGANIZER - SAFE V2
echo ============================================================
echo.
echo This version fixes the PowerShell parser/encoding error.
echo It creates a backup before organizing anything.
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0ORGANIZE_YSMF_STORE_SAFE_V2.ps1"
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
    echo Organizer finished successfully.
) else (
    echo Organizer stopped or failed. Error code: %RC%
)
echo.
pause

popd
endlocal
