# YSMF Minimal — Drop 01 Updated Launch Plan
**Updated:** 18 August 2026  
**Launch:** Friday, 18 September 2026

## What is already done
- Drop 01 launch date locked.
- Six-product Minimal lineup locked.
- Three reveal videos completed.
- Minimal webpage built and release-ready.
- Minimal campaign film added to the webpage.
- Homepage, Signature, Shop and About pages polished.
- TikTok added to the site header.
- Instagram and TikTok YSMF accounts are live.
- TikTok Shop seller account has been approved / configured, but Fourthwall UK fulfilment is not directly integrated.
- Launch reminders already exist for Reveal 1, Reveal 2, Reveal 3, launch eve and launch day.

## Release timeline

### Now → 27 August
- Do not over-post the full collection.
- Finish checking Signature pricing and profit margins.
- Confirm Minimal product pricing and profit margins.
- Order / inspect samples where possible.
- Confirm Fourthwall product titles, descriptions, variants and collection membership.
- Make sure every Minimal item is still hidden/private until intended.

### 28 August — Reveal 1
**Hero product:** black YSMF hoodie with white chest logo.
- Post Reveal 1 video to YSMF TikTok + Instagram Reel.
- Share to Stories / personal channels where useful.
- Keep CTA simple: `Minimal — Drop 01 / 18.09.26`.
- Website can remain on the normal homepage.

### 4 September — Reveal 2
**Products:** cream tee + white dad hat.
- Post Reveal 2.
- Reinforce `Wear It Like You Mean It.`
- Keep the rest of the collection partially hidden.

### 11 September — Reveal 3
**Full six-piece collection.**
- Post full collection reveal.
- Begin showing the full Minimal page publicly if desired, but products can remain non-purchasable/private.
- Check mobile layout and all image/video loading.

### 12–16 September — Final QA
- Test `minimal.html?preview=1`.
- Test Home / Shop / Signature / Minimal / About on desktop + mobile.
- Confirm social links.
- Confirm campaign film autoplay is muted, looping and has no controls.
- Test Fourthwall product links and checkout path.
- Confirm currency behaviour.
- Confirm product prices and profit margins.
- Check spelling, sizing variants and product descriptions.
- Confirm `minimalCollectionSlug` in `assets/config.js`.
- Make sure GitHub Desktop has no uncommitted accidental files.
- Keep a backup ZIP/local copy.

### 17 September — Launch Eve
Use the included **17-Sep-Launch-Eve/index.html**.
- Replace your normal `index.html`.
- Replace `assets/styles.css` with the included release stylesheet.
- Push with GitHub Desktop.
- Hard refresh and test.
- Post launch-eve countdown content.
- Final Fourthwall checks.
- Prepare launch captions for TikTok / Instagram / Discord / personal socials.

Recommended config state:
```js
showMinimalInNavigation: true,
showMinimalTeaserOnHome: true,
minimalIsLive: false,
```
If you intentionally want the full Minimal page publicly browsable on launch eve, you can keep preview behaviour or make it visible manually, but products should not be purchasable before launch unless you deliberately choose that.

### 18 September — Launch Day
Before posting launch content:
1. Make the Fourthwall Minimal collection/products public.
2. Confirm the Minimal collection URL / slug.
3. Update config:
```js
showMinimalInNavigation: true,
showMinimalTeaserOnHome: true,
minimalIsLive: true,
```
4. Replace homepage with **18-Sep-Launch-Day/index.html**.
5. Push `index.html`, `assets/styles.css`, and `assets/config.js`.
6. Wait for GitHub Pages.
7. Hard refresh.
8. Test Home → Minimal → product → cart / checkout.
9. Test on mobile.
10. Only after checkout is confirmed, publish the launch posts.

### Launch content order
- YSMF Instagram Reel.
- YSMF TikTok.
- Instagram Story.
- Personal Instagram / Snapchat / Facebook where useful.
- Discord announcement.
- Twitch promotion / `!shop` / panel link.

## Things still worth completing before launch
1. **Minimal pricing + profit review** — important before products go public.
2. **Sample / quality check** — hoodie, tee and hat at minimum if budget allows.
3. **Full checkout test** — ideally a real low-risk test order or at least checkout flow to the payment stage.
4. **Launch captions prepared in advance** — do not write them under pressure on launch day.
5. **Product descriptions / size guides reviewed**.
6. **Correct TikTok Shop official profile** — unlink the accidental personal gaming account once TikTok's 24-hour restriction expires and link @ysmfapparel.
7. **Website domain** — useful later, but not required to launch Drop 01.
8. **Analytics baseline** — screenshot traffic / sales before launch so you can compare the first 24h, 72h and 7 days.

## Homepage strategy
Do not permanently delete the current Signature-led homepage.

Keep three local versions:
- **Normal homepage** — current site.
- **Launch Eve homepage** — 17 September.
- **Launch Day homepage** — 18 September onward for the launch push.

After the initial launch push (roughly 1–2 weeks), decide whether the homepage should:
- stay Minimal-led,
- return to a balanced Signature + Minimal layout,
- or feature whichever collection is currently selling best.

## Core launch rule
Do not publish the launch post until:
**Minimal products are public + homepage is live + checkout path has been tested.**
