# YSMF Project Log — 17 August 2026

## Purpose
This file is the recovery/source-of-truth summary for the YSMF clothing brand project.
Keep a copy inside the main YSMF website / merch project folder.
At the end of each work session, create a new dated version so the project can be quickly restored if a ChatGPT conversation becomes unavailable or loses visible history.

---

## Brand Identity

- **YSMF** is the main clothing brand.
- **itsFains** is the creator/founder identity, not the primary clothing logo.
- **“You Sexy Motherfuckers”** is mainly used for louder statement pieces.
- **YSMF** is used for cleaner, more wearable branding.
- Main goal: make people think **“YSMF is a clothing brand”**, not **“this is Twitch merch.”**

### Core visual direction
- Premium streetwear
- Modern
- Clean
- Confident
- High-end rather than generic streamer merch
- Strong negative space
- Product-focused presentation

### Core colours
- White
- Charcoal / black
- Soft pink
- Cream / off-white

### Reserved colours
- Red and silver are being kept for later statement/special pieces.

---

## Collections

### Current Collection
**YSMF Signature**

Direction:
- Louder
- Red / white / black
- Aggressive streetwear
- Distressed / graffiti-inspired artwork
- Full “You Sexy Motherfuckers” identity can be used here
- Stop endlessly adding products to Signature
- Allow the collection time to sell before expanding

### Next Collection
**YSMF Minimal — Drop 01**

Direction:
- Genuinely minimal
- Small chest logos
- Clean empty space
- Mostly unisex
- No giant graphics
- No unnecessary sleeve filling
- No random accessory bloat
- Premium everyday wear

Current Minimal product references:
1. White YSMF dad hat
2. Cream / off-white YSMF tee
3. Black YSMF tee
4. Pepper crewneck
5. Black YSMF hoodie
6. Optional black tonal hoodie / charcoal YSMF version

Planned core Minimal concepts also include:
- Black premium hoodie + white YSMF
- Black tonal hoodie + charcoal YSMF
- Black premium / oversized tee + white YSMF
- Cream / off-white tee + black YSMF
- Soft pink hoodie or sweatshirt + white YSMF
- Black cap + white embroidered YSMF

---

## Product / Quality Plan

Before properly launching YSMF Minimal:

- Order samples
- At minimum sample:
  - Hoodie
  - Tee
  - Cap
- Check:
  - Print quality
  - Embroidery quality
  - Fit
  - Fabric quality
  - Wash performance
- Adjust logo size if needed
- Use real product photos when possible
- Wear YSMF on stream
- Use AI mockups mainly for concepts and early promotion

---

## Website Setup

The current YSMF website is kept locally on the desktop.

Workflow:
- Edit the site locally
- Use **GitHub Desktop**
- Push changes to GitHub
- GitHub hosts the front-facing custom YSMF website
- **Fourthwall remains the commerce/backend/fulfilment system**

The custom site was built to feel like a real clothing-brand storefront rather than a stock creator merch page.

Recovered website development stages include:
- Store starter
- Stage 2 store update
- Home / Signature updates
- Hero frame fix
- Header / footer / currency update
- Local image-path update

Website direction:
- Clean homepage
- Product-focused
- Strong hero section
- Signature collection section
- Shop
- About
- Individual product areas/pages
- Later add YSMF Minimal properly when launched

Current / intended navigation:
- HOME
- SHOP
- SIGNATURE COLLECTION
- Later: YSMF MINIMAL

---

## Fourthwall

Fourthwall is used for:
- Product setup
- Store backend
- Orders
- Fulfilment
- Commerce links

The custom GitHub site is the branded front end.

---

## Signature Hoodie / Graphic Direction

Main Signature identity:
- Black base
- Red / white graphic language
- Full “YOU SEXY MOTHERFUCKERS” statement branding

Sleeve work:
- Text on sleeves was rejected because it felt corny
- Replaced with abstract streetwear graphics
- Left sleeve: red / white / black aggressive graphic with crown element
- Right sleeve: complementary but different, no crown
- No unnecessary sleeve text
- Designs were adapted around Fourthwall’s narrow sleeve print area

---

## Promo / Gemini / Veo Direction

### General rules
Promos should feel:
- Premium
- Cinematic
- High-end
- Product-accurate
- Fashion-first
- Clean
- Modern
- Intentional

Avoid:
- Cheesy effects
- Cheap gaming aesthetic
- Random products
- Random models
- Warped text
- Altered logos
- Misspelled YSMF
- Redesigned garments
- Fake website elements
- Unnecessary clutter

### Minimal promo palette
- Black
- Charcoal
- White
- Soft cream

### Future-drop teaser palette
- Black
- Red
- White
- Pink
- Metallic accents where appropriate

### Minimal promo product references
- White YSMF dad hat
- Cream YSMF tee
- Black YSMF tee
- Pepper crewneck
- Black YSMF hoodie
- Optional black tonal hoodie

### Typical Minimal promo style
- 9:16 vertical for Instagram / Snapchat
- 6–10 seconds
- Dark studio start
- Slow or smooth product reveals
- Full-product shots mixed with macro fabric/logo details
- Clean studio lighting
- Subtle shadows
- Premium transitions
- Teaser feel, not full product breakdown

Common campaign copy:
- YSMF MINIMAL — DROP 01
- WEAR IT LIKE YOU MEAN IT.
- COMING SOON.
- BE READY.
- YSMF MINIMAL
- DROP 01

### Website hero promo
- 16:9 landscape
- 8–12 seconds
- Smooth premium pacing
- Product closeups
- Flat lays
- Logo / embroidery / fabric details
- Loop-friendly where possible

### Stream popup promo
- Pure chroma-key green background
- Jumper/product as hero
- 5–8 seconds
- Clean animated entrance
- Subtle rotation / float / zoom
- Centered
- Bold but uncluttered
- Suitable for OBS overlay use

### Website launch promo
- Uses exact website screenshots as reference
- Starts on “WEAR THE ATTITUDE.”
- Scroll/push into “Loud By Design”
- Reveal Signature product grid
- End on IF / YSMF branding
- Black / red / white streetwear campaign style
- Do not invent or redesign website elements

---

## Future Collection Concepts

Possible future YSMF / itsFains directions already explored:

- Afterglow
- Midnight Luxe
- Varsity Club
- Chaos Graffiti
- Repeat Strike
- Heartline
- Monogram Grid
- Warning Tape
- Checker Noise
- Sticker Bomb

These are future ideas, not products to dump into the current collection immediately.

### Future teaser philosophy
The goal is to show that YSMF has a much larger future without over-revealing everything at once.

Future campaign look:
- Black studio
- Deep shadows
- Red accents
- Hot pink accents
- White highlights
- Smoke
- Metallic reflections
- Macro product/detail shots
- Fast editorial cuts
- Controlled glitch / flash effects
- Luxury fashion-trailer feel

---

## Release Strategy

- Let Signature breathe before constantly adding more
- Watch what people actually buy
- Launch Minimal as a controlled small drop
- Start with about 6 products
- Keep most products unisex
- Possibly use one women-specific fit
- Do not create separate Men’s and Women’s collections yet
- Tease the next collection over several weeks
- Avoid forcing a full new collection every month
- Aim for major collections roughly every 6–10 weeks when there is something genuinely strong
- Between drops, add a colourway or one strong product instead
- Grow Minimal only when customer behaviour supports it
- Long-term core Minimal cap: roughly 10–12 products

---

## Marketing / Integration Tasks

Planned:
- Twitch `!shop` or `!merch` command
- Shop link in Twitch About
- Small merch popup / overlay during streams
- QR code for occasional stream promotion
- Fourthwall Twitch integrations
- Instagram Shopping
- Later investigate TikTok / YouTube shop integrations
- Proper social-sharing image for the store
- Eventually buy a clean YSMF domain
- Eventually create separate YSMF Instagram / TikTok pages
- Post clothing-focused content, not only streamer content
- Show real people wearing YSMF

---

## File / Asset Recovery

A substantial amount of YSMF work still exists in ChatGPT’s Library, including:
- Generated campaign images
- Concept boards
- Sleeve artwork
- Website mockups
- Product imagery
- Website ZIP backups
- Signature promo artwork
- Minimal storefront concepts
- Future collection moodboards

Known surviving examples include:
- Gritty Red White Black Sleeve Abstract
- Monochrome Luxury Monogram Brand Board
- Edgy Black and Red Hoodie Merch Banner
- Gritty Red-Lit Attitude Hoodie Poster
- YSMF Minimal Drop 01 Storefront
- YSMF Drop 01 Streetwear Campaign
- itsFains Future Collection Mood Board
- itsFains Pattern Collection Moodboard

The local website folder + GitHub history + ChatGPT Library should be treated as the project archive.
The chat itself should be treated as the working discussion layer, not the only copy of important work.

---

## Daily Backup Routine

At the end of every substantial YSMF work session:

1. Ask ChatGPT: **“Summarise everything we changed today for the YSMF project log.”**
2. Save the result as:
   `YSMF_Project_Log_YYYY-MM-DD.md`
3. Put it inside the YSMF website / merch project folder.
4. Commit the updated log through GitHub Desktop with the rest of the website changes.
5. Keep the previous dated logs rather than overwriting them.
6. When starting a new chat after any history problem, upload or paste the newest log and say:
   **“This is the current YSMF project state. Continue from here.”**

This creates a recoverable daily history even if the visible chat ever breaks again.

---

## Late Session Update — Social Launch & Minimal Campaign

### Minimal launch date
- **YSMF Minimal — Drop 01 launches Friday 18 September 2026.**

### Confirmed six-product Minimal lineup
1. Black YSMF T-shirt — white chest logo
2. White YSMF dad hat — black front logo
3. Black YSMF hoodie — white chest logo
4. Black tonal YSMF hoodie — black tonal chest logo
5. Pepper / grey YSMF crewneck — white chest logo
6. Cream / off-white YSMF T-shirt — black chest logo

### Reveal schedule
- **28 Aug 2026 — Reveal 1:** black YSMF hoodie with white logo; dark, premium hero-piece video.
- **4 Sep 2026 — Reveal 2:** cream/off-white tee + white dad hat; lighter, clean editorial video.
- **11 Sep 2026 — Reveal 3:** full six-product Minimal collection reveal.
- **17 Sep 2026 — Launch Eve:** countdown plus website/Fourthwall/Twitch checks.
- **18 Sep 2026 — Launch Day:** publish YSMF Minimal — Drop 01 and push launch content.
- Reminders were created for all five dates.

### Social accounts created
- Dedicated YSMF brand email created.
- **TikTok:** @ysmfapparel
- **Instagram:** @ysmfapparel
- TikTok/Instagram use the gold/cream YSMF logo without “itsFains”.
- First YSMF brand-introduction TikTok video has been posted.
- TikTok initially returned a “failed” error when trying to pin the first video; leave the post live and retry later.
- Instagram first Reel is the YSMF introduction video.
- Instagram is being set up as a Professional **Business** account with the YSMF website linked.
- Instagram: https://www.instagram.com/ysmfapparel/

### TikTok Shop
- UK TikTok Shop seller account created.
- Currently under review; TikTok stated approximately **1–3 business days**.
- Fourthwall’s native TikTok Shop integration is currently US-only, so it cannot directly connect to the UK TikTok Shop.
- Decision: **do not add another fulfilment provider right now.**
- Fourthwall remains the main commerce / fulfilment backend.
- TikTok will primarily be used as a marketing/discovery channel for now.
- Keep the TikTok Shop account ready in case UK support becomes available later.

### Current slogans
- **YSMF Signature:** “WEAR THE ATTITUDE.”
- Signature secondary phrase: **“LOUD BY DESIGN.”**
- **YSMF Minimal:** “WEAR IT LIKE YOU MEAN IT.”

### Twitch branding
Existing panel set confirmed:
- Donation
- Discord
- TikTok
- Instagram
- Merch

Panel sizing guidance used:
- **320 px wide**
- Preserve original aspect ratio rather than stretching banners.

### AI video workflow rules reinforced
For Gemini / Veo:
- Use exact product references.
- Do not recolour products.
- Do not alter YSMF logos or placements.
- Do not add random text to garments.
- Do not invent extra products or graphics.
- Add important typography externally when AI text generation is unreliable.
- Upload only the references needed for each video when possible.

### Current end-of-day position
Completed / underway:
- Launch date locked
- Three reveal concepts/prompts prepared
- Reveal reminders scheduled
- Dedicated YSMF email created
- TikTok @ysmfapparel live
- Instagram @ysmfapparel live
- TikTok Shop UK created and under review
- YSMF intro video posted
- Social promotion underway
- Fourthwall remains fulfilment backend
- Twitch panel assets confirmed

### Next priorities
1. Finish Instagram professional/business setup and profile polish.
2. Keep YSMF TikTok/Instagram branding consistent.
3. Prepare reveal videos in advance but hold them for scheduled dates.
4. Arrange Minimal samples / quality checks before launch.
5. Continue building YSMF as a standalone apparel brand rather than streamer-only merch.

