YSMF LOCAL PROJECT STRUCTURE
============================

LIVE WEBSITE — KEEP AT STORE ROOT
---------------------------------
index.html
shop.html
signature.html
minimal.html
about.html
product.html
404.html
README.md
assets/
.git/                         <- GitHub/GitHub Desktop metadata; organizer NEVER touches this
BACKUP_YSMF_SITE_V2.bat
BACKUP_YSMF_SITE_V2.ps1
.gitignore

LOCAL PROJECT MANAGEMENT
------------------------
_PROJECT_LOCAL/
  CHANGE_NOTES/              Old README/update notes from previous site versions
  PACKAGES/                  Old ZIP release/update packages
  PLANS/                     Drop plans and launch checklists
  PROJECT_LOGS/              Dated YSMF recovery/project logs
  RELEASE_FILES/
    DROP_01/
      2026-08-18_NORMAL_HOME_REFERENCE/
      2026-09-17_LAUNCH_EVE/
      2026-09-18_LAUNCH_DAY/
  LEGACY_TOOLS/              Old/broken backup tools kept only for recovery
  UNSORTED_REVIEW/           Reserved for anything unclear later

BACKUPS/
  Existing backups remain exactly where they are.
  The working V2 backup tool continues creating timestamped backups here.

WHY THIS IS SAFER
-----------------
- GitHub Pages still sees the same live HTML/assets paths.
- .git is not moved, replaced, or recreated.
- Old update ZIPs and notes no longer clutter the live website root.
- BACKUPS and _PROJECT_LOCAL are ignored by Git after organization.
- Release-state homepage files are easy to find without touching the live page.

NORMAL WORKFLOW
---------------
1. Double-click BACKUP_YSMF_SITE_V2.bat.
2. Make/edit website files.
3. Check the site locally.
4. GitHub Desktop -> review changes -> commit -> Push Origin.
5. Keep launch-only files inside _PROJECT_LOCAL until their release date.

DROP 01 HOMEPAGE WORKFLOW
-------------------------
17 Sep 2026:
  Use _PROJECT_LOCAL/RELEASE_FILES/DROP_01/2026-09-17_LAUNCH_EVE/

18 Sep 2026:
  Use _PROJECT_LOCAL/RELEASE_FILES/DROP_01/2026-09-18_LAUNCH_DAY/

The current normal homepage reference is kept alongside them so reverting is simple.
