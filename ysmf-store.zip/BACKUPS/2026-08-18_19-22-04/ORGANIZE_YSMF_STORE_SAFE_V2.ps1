$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $root

function Stop-WithMessage {
    param([string]$Message)

    Write-Host ""
    Write-Host "YSMF ORGANIZER STOPPED" -ForegroundColor Red
    Write-Host $Message
    Write-Host ""
    exit 1
}

$indexPath = Join-Path $root "index.html"
$assetsPath = Join-Path $root "assets"

if (-not (Test-Path -LiteralPath $indexPath)) {
    Stop-WithMessage "index.html was not found beside this organizer. Put the organizer files in the root of the YSMF store."
}

if (-not (Test-Path -LiteralPath $assetsPath)) {
    Stop-WithMessage "The assets folder was not found beside this organizer."
}

Write-Host ""
Write-Host "============================================================"
Write-Host "  YSMF STORE ORGANIZER - SAFE V2"
Write-Host "============================================================"
Write-Host "Root: $root"
Write-Host ""

# 1. Create a backup before moving anything.
$backupTool = Join-Path $root "BACKUP_YSMF_SITE_V2.ps1"

if (Test-Path -LiteralPath $backupTool) {
    Write-Host "Creating pre-organization backup using the V2 backup tool..."
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$backupTool"
    $backupExit = $LASTEXITCODE

    if ($backupExit -ne 0) {
        Stop-WithMessage "The pre-organization backup failed. Nothing has been organized."
    }
}
else {
    Write-Host "V2 backup tool not found. Creating an emergency snapshot..."

    $stamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
    $backupRoot = Join-Path $root "BACKUPS"
    $dest = Join-Path $backupRoot ($stamp + "_PRE_ORGANIZE")

    New-Item -ItemType Directory -Path $dest -Force | Out-Null

    $items = Get-ChildItem -LiteralPath $root -Force | Where-Object {
        $_.Name -ne "BACKUPS" -and
        $_.Name -ne ".git" -and
        $_.Name -ne "_PROJECT_LOCAL"
    }

    foreach ($item in $items) {
        $target = Join-Path $dest $item.Name
        Copy-Item -LiteralPath $item.FullName -Destination $target -Recurse -Force
    }

    Write-Host "Emergency snapshot created:"
    Write-Host $dest
}

# 2. Create local project folders.
$project = Join-Path $root "_PROJECT_LOCAL"

$folders = @(
    "CHANGE_NOTES",
    "PACKAGES",
    "PLANS",
    "PROJECT_LOGS",
    "RELEASE_FILES",
    "LEGACY_TOOLS",
    "UNSORTED_REVIEW"
)

foreach ($folder in $folders) {
    New-Item -ItemType Directory -Path (Join-Path $project $folder) -Force | Out-Null
}

# 3. Import prepared payload.
$payload = Join-Path $root "_ORGANIZER_PAYLOAD"

if (Test-Path -LiteralPath $payload) {
    Write-Host "Importing prepared release and project files..."

    Get-ChildItem -LiteralPath $payload -Force | ForEach-Object {
        $dest = Join-Path $project $_.Name

        if ($_.PSIsContainer) {
            New-Item -ItemType Directory -Path $dest -Force | Out-Null

            Get-ChildItem -LiteralPath $_.FullName -Force | ForEach-Object {
                Copy-Item -LiteralPath $_.FullName -Destination $dest -Recurse -Force
            }
        }
        else {
            Copy-Item -LiteralPath $_.FullName -Destination $dest -Force
        }
    }
}

# 4. Safe helper for moving non-live files.
function Move-IfExists {
    param(
        [string]$Name,
        [string]$Folder
    )

    $src = Join-Path $root $Name

    if (-not (Test-Path -LiteralPath $src)) {
        return
    }

    $destDir = Join-Path $project $Folder
    New-Item -ItemType Directory -Path $destDir -Force | Out-Null

    $dest = Join-Path $destDir ([IO.Path]::GetFileName($Name))

    if (Test-Path -LiteralPath $dest) {
        $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
        $baseName = [IO.Path]::GetFileNameWithoutExtension($dest)
        $ext = [IO.Path]::GetExtension($dest)
        $dest = Join-Path $destDir ($baseName + "_" + $stamp + $ext)
    }

    Move-Item -LiteralPath $src -Destination $dest
    Write-Host "Moved: $Name -> $Folder"
}

# 5. Move old change notes out of the live root.
$noteNames = @(
    "README_HOMEPAGE_V5.txt",
    "README_MINIMAL_UPDATE.txt",
    "README_MINIMAL_V3.txt",
    "README_MINIMAL_V4.txt",
    "README_MINIMAL_VIDEO_V9.txt",
    "README_SHOP_ABOUT_V7.txt",
    "README_SIGNATURE_AUTOPLAY_V10.txt",
    "README_SIGNATURE_V6.txt",
    "README_STAGE2.md",
    "README_TIKTOK_HEADER_V8.txt",
    "README_BACKUP_FIX_V2.txt",
    "README_BACKUP_SYSTEM.txt"
)

foreach ($name in $noteNames) {
    Move-IfExists -Name $name -Folder "CHANGE_NOTES"
}

# 6. Move project plans and logs.
Get-ChildItem -LiteralPath $root -File -Filter "YSMF_Drop01_*Plan*.md" -ErrorAction SilentlyContinue | ForEach-Object {
    Move-IfExists -Name $_.Name -Folder "PLANS"
}

Get-ChildItem -LiteralPath $root -File -Filter "YSMF_Project_Log_*.md" -ErrorAction SilentlyContinue | ForEach-Object {
    Move-IfExists -Name $_.Name -Folder "PROJECT_LOGS"
}

# 7. Move old generated ZIP packages.
Get-ChildItem -LiteralPath $root -File -Filter "YSMF_*.zip" -ErrorAction SilentlyContinue | ForEach-Object {
    Move-IfExists -Name $_.Name -Folder "PACKAGES"
}

# 8. Move only the old broken V1 backup batch file if it exists.
Move-IfExists -Name "BACKUP_YSMF_SITE.bat" -Folder "LEGACY_TOOLS"

# Keep BACKUP_YSMF_SITE_V2.bat and BACKUP_YSMF_SITE_V2.ps1 in root.

# 9. Copy prepared release folders from BACKUPS if they exist.
$releaseRoot = Join-Path $project "RELEASE_FILES\DROP_01"
New-Item -ItemType Directory -Path $releaseRoot -Force | Out-Null

$releaseNames = @(
    "2026-08-18_PRE_DROP01_REFERENCE",
    "2026-09-17_LAUNCH_EVE",
    "2026-09-18_LAUNCH_DAY"
)

foreach ($releaseName in $releaseNames) {
    $src = Join-Path $root ("BACKUPS\" + $releaseName)

    if (Test-Path -LiteralPath $src) {
        $dst = Join-Path $releaseRoot $releaseName
        New-Item -ItemType Directory -Path $dst -Force | Out-Null

        Get-ChildItem -LiteralPath $src -Force | ForEach-Object {
            Copy-Item -LiteralPath $_.FullName -Destination $dst -Recurse -Force
        }
    }
}

# 10. Add local-only paths to .gitignore.
$gitignore = Join-Path $root ".gitignore"

if (-not (Test-Path -LiteralPath $gitignore)) {
    New-Item -ItemType File -Path $gitignore -Force | Out-Null
}

$ignoreLines = @(
    "# YSMF local project management and backups",
    "/BACKUPS/",
    "/_PROJECT_LOCAL/",
    "/_ORGANIZER_PAYLOAD/",
    "/ORGANIZE_YSMF_STORE_SAFE_V2.bat",
    "/ORGANIZE_YSMF_STORE_SAFE_V2.ps1",
    "/BACKUP_YSMF_SITE_V2.bat",
    "/BACKUP_YSMF_SITE_V2.ps1"
)

$currentIgnore = @()
if (Test-Path -LiteralPath $gitignore) {
    $currentIgnore = @(Get-Content -LiteralPath $gitignore -ErrorAction SilentlyContinue)
}

foreach ($line in $ignoreLines) {
    if ($currentIgnore -notcontains $line) {
        Add-Content -LiteralPath $gitignore -Value $line
        $currentIgnore += $line
    }
}

# 11. Write a simple live-root manifest.
$manifest = Join-Path $project "LIVE_ROOT_AFTER_ORGANIZE.txt"

$manifestLines = @()
$manifestLines += "YSMF LIVE ROOT AFTER ORGANIZATION"
$manifestLines += "Generated: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
$manifestLines += ""
$manifestLines += "Items remaining in the store root:"
$manifestLines += (Get-ChildItem -LiteralPath $root -Force | Sort-Object Name | ForEach-Object { $_.Name })

$manifestLines | Set-Content -LiteralPath $manifest -Encoding UTF8

Write-Host ""
Write-Host "============================================================"
Write-Host "  YSMF STORE ORGANIZED SUCCESSFULLY"
Write-Host "============================================================" -ForegroundColor Green
Write-Host ""
Write-Host "Live website files stayed at the root."
Write-Host ".git was not touched."
Write-Host "BACKUPS was not moved or deleted."
Write-Host "Old notes and packages are now in _PROJECT_LOCAL."
Write-Host ""
Write-Host "GitHub Desktop may show old README or ZIP files removed from"
Write-Host "the repository root and a new .gitignore file. That is expected."
Write-Host "The live website HTML and assets were not renamed or moved."
Write-Host ""
exit 0
