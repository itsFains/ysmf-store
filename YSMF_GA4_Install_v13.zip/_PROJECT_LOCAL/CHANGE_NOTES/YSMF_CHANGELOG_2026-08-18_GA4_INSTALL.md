# YSMF Change Note — Google Analytics 4 Install

**Date:** 18 August 2026  
**Measurement ID:** `G-NJK2H4R8VE`

## Change
Installed the Google Analytics 4 Google tag in the `<head>` of the live customer-facing YSMF pages:

- `index.html`
- `shop.html`
- `signature.html`
- `minimal.html`
- `about.html`
- `product.html`

Also added the same GA4 tag to the active Drop 01 homepage release states so tracking will remain present when those homepages are swapped in:

- `_PROJECT_LOCAL/RELEASE_FILES/DROP_01/2026-08-18_NORMAL_HOME_REFERENCE/index.html`
- `_PROJECT_LOCAL/RELEASE_FILES/DROP_01/2026-09-17_LAUNCH_EVE/index.html`
- `_PROJECT_LOCAL/RELEASE_FILES/DROP_01/2026-09-18_LAUNCH_DAY/index.html`

## Not changed
- `assets/app.js`
- `assets/config.js`
- `assets/styles.css`
- `.git`
- `BACKUPS`
- historical `2026-08-18_PRE_DROP01_REFERENCE`
- `404.html`

## Install
1. Run `BACKUP_YSMF_SITE_V2.bat`.
2. Copy the contents of this update package into the live `ysmf-store` root.
3. Allow Windows to merge `_PROJECT_LOCAL` folders and replace the matching HTML files.
4. Commit and Push Origin in GitHub Desktop.
5. After GitHub Pages deploys, open the live site and verify traffic in Google Analytics Realtime.

## Privacy follow-up
The supplied Google tag starts Analytics when the page loads. A UK/EU cookie-consent setup should be handled separately before relying on the final production tracking setup.
