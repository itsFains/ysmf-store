YSMF / itsFains — Homepage + Signature Sirv Update

REPLACE ONLY:
- index.html
- signature.html
- assets/styles.css

DO NOT REPLACE:
- assets/config.js   (keeps your Fourthwall storefront token)
- assets/app.js      (keeps your working product/cart logic)

SIRV ASSETS NOW USED:
Homepage hero / Signature 'Original Statement':
https://itsfains.sirv.com/YSMF/Webpage%20design%202.png

Homepage + Signature 'Loud by Design':
https://itsfains.sirv.com/YSMF/Webpage%20design.png

Signature video:
https://itsfains.sirv.com/YSMF/Jumper%20design%201.mp4

After replacing:
1. GitHub Desktop → review changes
2. Commit to main
3. Push origin
4. Wait for GitHub Pages deployment
5. Hard refresh the live site with Ctrl + F5
