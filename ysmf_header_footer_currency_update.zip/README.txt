YSMF HEADER / FOOTER / CURRENCY UPDATE

Replace ONLY:
- assets/app.js
- assets/styles.css

DO NOT replace:
- assets/config.js
- any HTML files

Changes:
1. Replaces the placeholder Twitch / Instagram glyphs with clean inline SVG logos.
   Your existing links are preserved.
2. Replaces the footer's text 'IF' with assets/if-logo.png — the same logo file used in the header.
3. Adds the full 17-currency Fourthwall list:
   USD, EUR, CAD, GBP, AUD, NZD, BRL, MXN, SEK, NOK, DKK, PLN, JPY,
   INR, MYR, SGD, CHF.
4. Keeps the user's selected currency saved in localStorage like before.

Deploy:
GitHub Desktop -> Commit -> Push origin -> wait for Pages -> Ctrl+F5.

NOTE:
Fourthwall's current Help Center lists 17 storefront currencies including CHF.
One Storefront API reference page currently lists 16 and omits CHF, while other
Fourthwall docs include CHF. Test CHF once after deployment; if that one option
misbehaves in the custom storefront, remove CHF from FOURTHWALL_CURRENCIES until
the API reference is brought into line.
