YSMF HERO FRAME FIX

Replace ONLY:
assets/styles.css

Do not replace index.html, signature.html, app.js or config.js.

What this changes:
- removes the ugly solid block feel behind the homepage hero artwork
- applies the same fix to the Signature hero
- adds a dark charcoal floating panel
- adds a soft red glow behind the campaign image
- keeps only a thin subtle red edge
- preserves the Sirv campaign images themselves

After replacing:
1. GitHub Desktop -> Commit to main
2. Push origin
3. Wait for GitHub Pages deployment
4. Ctrl + F5 on the live site
