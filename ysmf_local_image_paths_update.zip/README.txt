YSMF LOCAL IMAGE PATH UPDATE

You have moved these two images into the GitHub assets folder:

assets/Webpage design 2.png
assets/Webpage design.png

This update switches the website to load those images locally from GitHub Pages.

REPLACE ONLY:
- index.html
- signature.html

KEEP AS-IS:
- assets/styles.css
- assets/app.js
- assets/config.js

VIDEO:
The Signature MP4 still loads from Sirv:
https://itsfains.sirv.com/YSMF/Jumper%20design%201.mp4

IMPORTANT:
Make sure these exact image files are also committed and pushed to GitHub:
- assets/Webpage design 2.png
- assets/Webpage design.png

GitHub Pages is case-sensitive, so keep the names exactly the same.

Then:
1. Commit changes in GitHub Desktop
2. Push origin
3. Wait for GitHub Pages deployment
4. Ctrl + F5
